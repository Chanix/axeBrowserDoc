/*
 * 获取并保存 Bing 背景壁纸
 *
 * axebrowser@foxmail.com
 * 2020-11-25
 */
const APP_VERSION = `20.11.25`;
const APP_HELP = `
这是一个访问，分析，并下载特定资源的例子，运行模式为“命令行模式”。

在本例中，访问 cn.bing.com，并从页面中分析得到壁纸的地址。
然后调用外部命令将图片下载并保存起来。

本例在 Win10 家庭版下调试运行通过，下载时调用了 curl（Invoke-WebRequest 的别名）。
若为其他系统，请自行安装 curl 工具或者调用其他下载工具。

图片保存位置默认为当前用户的桌面，文件名为 yyyy-MM-dd_hh-mm-ss.jpg，请按实际需求进行修改。
`


// 应用的名称
const APP_NAME = `获取并保存 Bing 背景壁纸`;
// BING 的网址
const URL_BING = `https://cn.bing.com`;
// 图片保存的文件夹，请按照自己的实际情况修改。
const SAVE_PATH = __AXE__.fsys.getUserDesktopDir();

/*
 * before 函数定义，这个函数会在访问网址前执行，且运行于单独的浏览器环境。
 */
function before() {
    __AXE__.console.log(`========================================`);
    __AXE__.console.log(`= ${APP_NAME} ver ${APP_VERSION}`);
    __AXE__.console.log(`========================================`);
    __AXE__.console.log(``);
    __AXE__.console.log(`${APP_HELP}`);
    // 设置窗口标题
    __AXE__.console.setTitle(`${APP_NAME}`);
    // 设置打开的网址
    __AXE__.setHome(URL_BING);
}

/*
 * after 函数定义，这个函数会在访问网址后执行，运行于访问该网址的浏览器环境。
 */
function after() {
    // 获得背景图的网址
    let imgurl = document.getElementById('bgLink').href;
    // 分析获得高清版本
    let imgurl_uhd = imgurl.slice(0, imgurl.indexOf('&'));
    imgurl_uhd = `${imgurl_uhd.slice(0, imgurl_uhd.lastIndexOf('_'))}_UHD.jpg&pid=hp&w=3840&h=2160&rs=1&c=4&r=0`;

    // 拼凑出保存的文件名：yyyy-MM-dd_hh-mm-ss.jpg
    let filename = `${SAVE_PATH}\\${new Date().format("yyyy-MM-dd_hh-mm-ss")}.jpg`;

    // 调用 curl 来下载并保存图片，并等待其结束。
    __AXE__.process.execWait(`curl`, `"${imgurl_uhd}" -o "${filename}"`);

    __AXE__.console.pause(false, `运行完毕，请按任意键退出...`);
    // 退出 axeBrowser
    __AXE__.exit();
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,                      //月份
        "d+": this.getDate(),                           //日
        "h+": this.getHours(),                          //小时
        "m+": this.getMinutes(),                        //分
        "s+": this.getSeconds(),                        //秒
        "q+": Math.floor((this.getMonth() + 3) / 3),    //季度
        "S": this.getMilliseconds()                     //毫秒
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}